import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationServiceDebugComponent } from './registration-service-debug.component';

describe('RegistrationServiceDebugComponent', () => {
  let component: RegistrationServiceDebugComponent;
  let fixture: ComponentFixture<RegistrationServiceDebugComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationServiceDebugComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationServiceDebugComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
