import { Component, OnInit } from '@angular/core';
import {RegistrationService} from "../registration.service";

@Component({
  selector: 'app-registration-service-debug',
  templateUrl: './registration-service-debug.component.html',
  styleUrls: ['./registration-service-debug.component.css']
})
export class RegistrationServiceDebugComponent implements OnInit {

  constructor(public registrationService: RegistrationService) { }

  ngOnInit() {
  }

}
