import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserCredFormComponent } from './user-cred-form.component';

describe('UserCredFormComponent', () => {
  let component: UserCredFormComponent;
  let fixture: ComponentFixture<UserCredFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserCredFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserCredFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
