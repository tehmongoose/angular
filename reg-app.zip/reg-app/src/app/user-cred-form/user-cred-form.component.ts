import {Component, OnInit} from '@angular/core';
import {RegistrationService} from "../registration.service";
import {PersonalInfo} from "../personal-info-form/PersonalInfo";

@Component({
  selector: 'app-user-cred-form',
  templateUrl: './user-cred-form.component.html',
  styleUrls: ['./user-cred-form.component.css']
})
export class UserCredFormComponent implements OnInit {

  title: string = "Input user name";

  form: PersonalInfo = this.registrationService.form;

  constructor(private registrationService: RegistrationService) {
  }

  ngOnInit() {
  }

  createCustomer(form: PersonalInfo) {
    this.registrationService.createCustomer(form);
  }
}
