import {Injectable} from '@angular/core';
import {PersonalInfo} from "./personal-info-form/PersonalInfo";

@Injectable()
export class RegistrationService {
  private _form: PersonalInfo = {
    firstName: "",
    lastName: "",
    dob: new Date(),
    email: "abc@defg.com",
    username: "",
    password: ""
  };

  private _isCreated: boolean = false;

  constructor() {
  }

  get form(): PersonalInfo {
    return this._form;
  }

  set form(value: PersonalInfo) {
    this._form = value;
  }

  get isCreated(): boolean {
    return this._isCreated;
  }

  createCustomer(form: PersonalInfo): boolean {
    if (form) {
      this._isCreated = true;
    }

    return this._isCreated;
  }

}
