export class PersonalInfo {
  firstName: string;
  lastName: string;
  email: string;
  dob: Date;
  username: string;
  password: string;
}
