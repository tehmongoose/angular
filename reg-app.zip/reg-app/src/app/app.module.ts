import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import {PersonalInfoFormComponent} from "./personal-info-form/personal-info-form.component";
import {FormsModule} from "@angular/forms";
import {RegistrationService} from "./registration.service";
import {AppRoutingModule} from "./app-routing.module";
import { UserCredFormComponent } from './user-cred-form/user-cred-form.component';
import { RegistrationServiceDebugComponent } from './registration-service-debug/registration-service-debug.component';


@NgModule({
  declarations: [
    AppComponent,

    PersonalInfoFormComponent,

    UserCredFormComponent,

    RegistrationServiceDebugComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [RegistrationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
