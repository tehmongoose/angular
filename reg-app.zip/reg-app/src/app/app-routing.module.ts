import {NgModule} from '@angular/core';
import {RouterModule, Routes} from "@angular/router";
import {PersonalInfoFormComponent} from "./personal-info-form/personal-info-form.component";
import {UserCredFormComponent} from "./user-cred-form/user-cred-form.component";


const routes: Routes = [
  { path: '', redirectTo: '/register-personal-info', pathMatch: 'full' },
  { path: 'register', redirectTo: '/register-personal-info', pathMatch: 'full' },
  { path: 'register-personal-info', component: PersonalInfoFormComponent },
  { path: 'register-credentials', component: UserCredFormComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {
}
